package com.example.springbootcrud.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.springbootcrud.bean.Subject;
import com.example.springbootcrud.repository.SubjectRepository;

@Service
public class SubjectService {

	@Autowired
	SubjectRepository subjectRepository;

	public List<Subject> getAllSubjects() {
		List<Subject> subjects = new ArrayList<>();
		subjectRepository.findAll().forEach(subjects::add);
		return subjects;
	}

	public void addsubject(Subject subject) {
		subjectRepository.save(subject);

	}

	public void updateSubject(int subjectId, Subject subject) {
		subjectRepository.save(subject);

	}

	public void deleteSubject(int subjectId) {
		subjectRepository.deleteById(subjectId);

	}

}
