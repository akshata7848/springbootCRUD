package com.example.springbootcrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootcrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
